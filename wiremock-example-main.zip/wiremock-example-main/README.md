# wiremock

- [Using WireMock with SOAP Web Services in Java](https://stackoverflow.com/a/51037786/1849597)

- Running the wiremock server as standalone

```sh
java -jar wiremock.jar --port 8088 --verbose
```

- Create a `mapping.json` file, put in my mock project `mappings` folder

```json
```

- Create a `response.xml` file, put it in the `__files` folder

```xml
```
